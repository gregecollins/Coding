Version 1.0.5 - 13 December 2019
- Updated Page Builderry Plugin

Version 1.0.4 - 22 January 2019
- Fixed demo import issue
- Fixed floating team grid
- Fixed issue with mobile menu

Version 1.0.3 - 9 December 2018
- Fixed issues with pricing table module
- Updated Header builder
- Updated plugins

Version 1.0.2 - 5 December 2018
- New option added  for related products
- Minor fixes
- Updated plugins

Version 1.0
- Initial release